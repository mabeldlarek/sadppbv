package com.belarek.SADPPBV.dto;

public class PontoDTO {
    private Long ponto_id;
    private String nome;
}
