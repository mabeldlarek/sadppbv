package com.belarek.SADPPBV.dto;

import lombok.Data;

@Data
public class LoginRequestDTO {
    private String senha;
    private int registro;
}
