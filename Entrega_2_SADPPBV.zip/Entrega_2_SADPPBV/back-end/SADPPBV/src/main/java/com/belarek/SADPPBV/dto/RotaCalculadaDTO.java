package com.belarek.SADPPBV.dto;

public class RotaCalculadaDTO {
    private Long id;
    private double distancia;
    private int ponto_inicial;
    private int ponto_final;
    private int status;
    private String direcao;
}
