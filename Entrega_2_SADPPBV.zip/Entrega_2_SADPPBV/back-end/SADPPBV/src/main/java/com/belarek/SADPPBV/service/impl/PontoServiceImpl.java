package com.belarek.SADPPBV.service.impl;

import com.belarek.SADPPBV.dto.PontoDTO;
import com.belarek.SADPPBV.service.PontoService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PontoServiceImpl implements PontoService {

    @Override
    public String createPonto(PontoDTO Ponto) {
        return null;
    }

    @Override
    public List<PontoDTO> listPontos() {
        return null;
    }
}
