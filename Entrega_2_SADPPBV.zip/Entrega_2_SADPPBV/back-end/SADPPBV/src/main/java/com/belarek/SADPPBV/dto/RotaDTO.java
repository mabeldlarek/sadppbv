package com.belarek.SADPPBV.dto;

public class RotaDTO {
    private String origem;
    private String destino;
}
