package com.belarek.SADPPBV.controller;

import com.belarek.SADPPBV.dto.ResponseDTO;
import com.belarek.SADPPBV.service.RotaService;

public class RotaController {
    private RotaService rotaService;
    private ResponseDTO response;
}
