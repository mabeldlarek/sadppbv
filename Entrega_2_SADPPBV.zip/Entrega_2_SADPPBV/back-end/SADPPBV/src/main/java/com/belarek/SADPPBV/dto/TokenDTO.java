package com.belarek.SADPPBV.dto;

import lombok.Data;

@Data
public class TokenDTO {
    boolean isValido;
}
