package com.belarek.SADPPBV.repository;

import com.belarek.SADPPBV.entity.Segmento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SegmentoRepository extends JpaRepository<Segmento, Long> {

}
