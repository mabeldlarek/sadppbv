package com.belarek.SADPPBV.service.impl;

import com.belarek.SADPPBV.dto.RotaCalculadaDTO;
import com.belarek.SADPPBV.dto.RotaDTO;
import com.belarek.SADPPBV.service.RotaService;
import org.springframework.stereotype.Service;

@Service
public class RotaServiceImpl implements RotaService {
    @Override
    public RotaCalculadaDTO getRota(RotaDTO rotaDTO) {
        return null;
    }
}
