package com.belarek.SADPPBV.service;

import com.belarek.SADPPBV.dto.RotaCalculadaDTO;
import com.belarek.SADPPBV.dto.RotaDTO;

public interface RotaService {

    RotaCalculadaDTO getRota(RotaDTO rotaDTO);
}
