import React, { useState } from 'react';
import NavigationAdm from '../../components/nav/NavigationAdm';

function AdmLogado() {

    return (
        <NavigationAdm/>
    );
  }

  export default AdmLogado;
